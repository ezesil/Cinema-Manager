﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema.UI.AdminViews
{
    public partial class PermissionsPanel : UserControl
    {
        /// <summary>
        /// Constructor por defecto
        /// </summary>
        public PermissionsPanel()
        {
            InitializeComponent();
            this.Name = "Permissions";
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {

        }
    }
}
